-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: uiet
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `subjects` (
  `sub_code` varchar(20) NOT NULL,
  `dep_id` varchar(10) NOT NULL,
  `semester` int(11) NOT NULL,
  `sub_name` varchar(80) NOT NULL,
  `sub_credit` int(11) NOT NULL,
  `F_id` varchar(10) NOT NULL,
  PRIMARY KEY (`dep_id`,`sub_code`),
  KEY `F_id` (`F_id`),
  CONSTRAINT `subject` FOREIGN KEY (`dep_id`) REFERENCES `department` (`dep_id`),
  CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`F_id`) REFERENCES `faculty` (`f_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES ('CHE-S201','CHE',3,'Process Calculations',4,'CHE-EID01'),('CHE-S202','CHE',3,'Transport Processes & Unit Operations-I (Fluid Mechanics)',4,'CHE-EID02'),('CHE-S203','CHE',4,'Chemical Engg. Thermodynamics',4,'CHE-EID03'),('CHE-S204','CHE',4,'Transport Processes & Unit Operation-II (Heat Transfer)',4,'CHE-EID07'),('CHE-S205','CHE',4,'Chemical Process Industries-I',4,'CHE-EID05'),('CHE-S206','CHE',4,'Transport Processes & Unit Operation-III (Mechanical Operations)',4,'CHE-EID04'),('CHE-S301','CHE',5,'Transport Processes & Unit Operation-IV (Mass Transfer-I)',4,'CHE-EID06'),('CHE-S302','CHE',5,'Chemical Process Industries-II',4,'CHE-EID04'),('CHE-S303','CHE',5,'Transport Process & Unit Operations Laboratory -I',4,'CHE-EID03'),('CHE-S304','CHE',5,'Chemical Reaction Engineering-I',4,'CHE-EID01'),('CHE-S305','CHE',6,'Transport Processes & Unit Operations-V (Mass Transfer-II)',4,'CHE-EID02'),('CHE-S306','CHE',6,'Instrumentation & Process Control ',4,'CHE-EID05'),('CHE-S307','CHE',6,'Chemical Engg. Design-I',4,'CHE-EID08'),('CHE-S308','CHE',6,'Transport Process & Unit Operations Laboratory-II',4,'CHE-EID06'),('CHE-S401','CHE',7,'Chemical Engg. Design-II',4,'CHE-EID03'),('CHE-S402','CHE',7,'Chemical Reaction Engineering -II',4,'CHE-EID05'),('CHE-S403','CHE',8,'Chemical Reaction Engg Lab',4,'CHE-EID06'),('CHE-S404','CHE',8,'Transport Phenomena',4,'CHE-EID05'),('CHE-S405','CHE',7,'Chemical Reaction Engineering -II',4,'CHE-EID07'),('CHE-S501','CHE',6,'Departmental Elective',4,'CHE-EID04'),('CHE-S504','CHE',8,'Departmental Elective-I',4,'CHE-EID08'),('CHE-S505','CHE',8,'Departmental Elective-II',4,'CHE-EID04'),('CHM-S101','CHE',2,'Chemistry-I',5,'CHM-EID01'),('CHM-S301','CHE',5,'Chemistry-II',4,'CHE-EID07'),('ESC-S101','CHE',2,'Basic Electrical & Electronics Engg.',5,'ECE-EID07'),('ESC-S201','CHE',3,'Engineering Mechanics',4,'MEE-EID07'),('ESC-S202','CHE',3,'Thermodynamics',4,'CHE-EID08'),('HSS-S101','CHE',1,'Communicative English',4,'HSS-EID03'),('HSS-S201','CHE',7,'Industrial Management',4,'HSS-EID04'),('HSS-S401','CHE',4,'Industrial Economics',4,'HSS-EID03'),('ISC-S101','CHE',1,'Programming & Computing',5,'IT-EID05'),('MTH-S101','CHE',1,'Mathematics-I',4,'MTH-EID02'),('MTH-S102','CHE',2,'Mathematics-II',4,'MTH-EID03'),('MTH-S201','CHE',3,'Mathematics-III',4,'MTH-EID03'),('PHY-S101','CHE',1,'Physics-I',5,'PHY-EID02'),('PHY-S102','CHE',2,'Physics-II',5,'PHY-EID05'),('PRT-S401','CHE',7,'B.Tech Project-I',4,'CHE-EID01'),('PRT-S402','CHE',8,'B.Tech Project-2',4,'CHE-EID01'),('SSM-S401','CHE',8,'Student Seminar',4,'CHE-EID02'),('SST-S301','CHE',7,'Summer Training',2,'CHE-EID02'),('TCA-S101','CHE',2,'Engineering Drawing',5,'MEE-EID05'),('TCA-S102','CHE',1,'Workshop Concepts',5,'MEE-EID06'),('CHM-S101','CSE',2,'Chemistry – I',5,'CHM-EID03'),('CSE-S201','CSE',3,'Data Structure',5,'CSE-EID02'),('CSE-S202','CSE',3,'Digital Electronics & Logic Design',4,'CSE-EID07'),('CSE-S204','CSE',4,'Object Oriented Programming (Using C++ or Java)',5,'CSE-EID08'),('CSE-S205','CSE',4,'Computer Organization',4,'CSE-EID07'),('CSE-S206','CSE',4,'Operating Systems',5,'CSE-EID04'),('CSE-S301','CSE',5,'Data Base Management System',5,'CSE-EID03'),('CSE-S302','CSE',5,'Design and Analysis of Algorithms',4,'CSE-EID01'),('CSE-S303','CSE',5,'Microprocessor',3,'CSE-EID04'),('CSE-S304','CSE',5,'Theory of Computation',4,'CSE-EID05'),('CSE-S305','CSE',6,'Compiler Design',5,'CSE-EID05'),('CSE-S306','CSE',6,'Computer Networks',5,'CSE-EID07'),('CSE-S307','CSE',6,'Software Engineering',4,'CSE-EID03'),('CSE-S401','CSE',7,'Computer Graphics',5,'CSE-EID06'),('ESC-S101','CSE',1,'Basic Electrical & Electronics Engineering',5,'ECE-EID12'),('ESC-S201','CSE',3,'Engineering Mechanics',4,'MEE-EID06'),('ESC-S202','CSE',3,'Thermodynamics',4,'CHE-EID08'),('HSS-S101','CSE',1,'Communicative English',2,'HSS-EID01'),('HSS-S201','CSE',7,'Industrial Management',4,'HSS-EID04'),('HSS-S301','CSE',6,'Professional Communication',2,'HSS-EID01'),('HSS-S401','CSE',4,'Industrial Economics',4,'HSS-EID02'),('ISC-S101','CSE',2,'Programming & Computing (C & UNIX)',5,'CSE-EID01'),('MTH- S102','CSE',2,'Mathematics – II',4,'MTH-EID01'),('MTH-S101','CSE',1,'Mathematics – I',4,'MTH-EID01'),('MTH-S201','CSE',3,'Mathematics – III',4,'MTH-EID01'),('MTH-S301','CSE',4,'Discrete Mathematics',4,'MTH-EID02'),('MTH-S501','CSE',5,'Numerical Methods',4,'CSE-EID08'),('PHY-S101','CSE',1,'Physics – I',5,'PHY-EID04'),('PHY-S102','CSE',2,'Physics – II',5,'PHY-EID03'),('PRT-S401','CSE',7,'B.Tech. Project I',4,'CSE-EID02'),('PRT-S402','CSE',8,'B.Tech Project II',4,'CSE-EID08'),('SSM-S401','CSE',7,'Student Seminar',2,'CSE-EID08'),('SST-S401','CSE',7,'Summer Training',2,'CSE-EID01'),('TCA-S101','CSE',1,'Engineering Drawing',5,'MEE-EID05'),('TCA-S102','CSE',2,'Workshop Concepts',5,'MEE-EID06'),('CHM-S101','IT',2,'Chemistry-I',5,'CHM-EID02'),('DIT-S201','IT',3,'Object Oriented Systems Theory',5,'IT-EID04'),('DIT-S202','IT',4,'Computer Organisation',4,'IT-EID05'),('DIT-S203','IT',3,'Digital Electronics',5,'IT-EID05'),('DIT-S204','IT',4,'PPL',4,'IT-EID02'),('DIT-S205','IT',3,'Data Structures',5,'IT-EID06'),('DIT-S206','IT',4,'Software Engineering',4,'IT-EID06'),('DIT-S301','IT',5,'Microprocessors',4,'IT-EID03'),('DIT-S302','IT',6,'Computer Networks',4,'IT-EID03'),('DIT-S303','IT',5,'Theory of computation',4,'IT-EID07'),('DIT-S305','IT',5,'Design & Analysis of Algorithm',4,'IT-EID06'),('DIT-S307','IT',5,'Data Base Management System',5,'IT-EID05'),('DIT-S308','IT',6,'Internet Technology',5,'IT-EID05'),('DIT-S309','IT',5,'Operating System',4,'IT-EID04'),('DIT-S401','IT',7,'Digital Image Processing',4,'IT-EID07'),('DIT-S402','IT',8,'Information Systems',4,'IT-EID06'),('ESC-S101','IT',2,'Basic Electrical & Electronics Engineering',5,'ECE-EID13'),('ESC-S201','IT',3,'Engineering Mechanics',4,'MEE-EID06'),('HSS-S101','IT',1,'Communicative English',4,'HSS-EID01'),('HSS-S201','IT',7,'Industrial Management',4,'HSS-EID04'),('HSS-S301','IT',6,'Professional Communication',2,'HSS-EID01'),('HSS-S401','IT',4,'INDUSTRIAL ECONOMICS',4,'HSS-EID03'),('ISC-S101','IT',1,'Programming and Computing (C & Unix)',5,'IT-EID03'),('MTH-S101','IT',1,'Mathematics-1',4,'MTH-EID02'),('MTH-S102','IT',2,'Mathematics-II',4,'MTH-EID01'),('MTH-S201','IT',3,'Mathematics III',4,'MTH-EID05'),('MTH-S302','IT',4,'DISCRETE MATHEMATICS',4,'MTH-EID04'),('PHY-S101','IT',1,'Physics-I',5,'PHY-EID04'),('PHY-S102','IT',2,'Physics-II',5,'PHY-EID03'),('PRT-S401','IT',7,'B.Tech Project I',4,'IT-EID01'),('PRT-S402','IT',8,'B.Tech Project II',4,'IT-EID01'),('SSM-S401','IT',7,'Student Seminar',2,'IT-EID02'),('SST-S303','IT',6,'Summer Training',2,'IT-EID02'),('TCA-S101','IT',2,'Engineering Drawing',4,'MEE-EID03'),('TCA-S102','IT',1,'Workshop Concepts',5,'MEE-EID06'),('CHM-S101','MEE',1,'Chemistry-I ',5,'CHM-EID03'),('CHM-S301','MEE',5,'Chemistry II / MTH-S301',5,'MEE-EID04'),('ESC-S101','MEE',1,'Basic Elect. & Elect. Engg.',5,'ECE-EID06'),('ESC-S201','MEE',3,'Engineering Mechanics',4,'MEE-EID06'),('ESC-S202','MEE',3,'Thermodynamics',4,'MEE-EID04'),('HSS-S101','MEE',2,'Communicative English',4,'HSS-EID03'),('HSS-S201','MEE',4,'Industrial Management',4,'HSS-EID04'),('HSS-S301','MEE',6,'Professional Communication',2,'HSS-EID01'),('HSS-S401','MEE',7,'Industrial Economics',4,'HSS-EID02'),('ISC-S101','MEE',2,'Programming and Computing',5,'IT-EID05'),('MEE-S201','MEE',3,'Mechanical Design & Drawing',5,'MEE-EID03'),('MEE-S202','MEE',3,'Basic Solid Mechanics',4,'MEE-EID07'),('MEE-S203','MEE',4,'Kinematics And Mechanism',4,'MEE-EID07'),('MEE-S204','MEE',4,'Basic Fluid Mechanics & Rate Processes',4,'MEE-EID02'),('MEE-S205','MEE',4,'Materials & Mechanical Metallurgy',4,'MEE-EID06'),('MEE-S206','MEE',4,'Advanced Solid Mechanics',4,'MEE-EID01'),('MEE-S301','MEE',5,'Dynamics of Machines & Vibrations',5,'MEE-EID07'),('MEE-S302','MEE',5,'Advanced Fluid Mech',5,'MEE-EID06'),('MEE-S303','MEE',5,'IC Engines, Steam & Nuclear Power',5,'MEE-EID05'),('MEE-S304','MEE',5,'Appl. Mech., Fluid Mech., Vibrations',5,'MEE-EID02'),('MEE-S305','MEE',6,'Heat Transfer',4,'MEE-EID07'),('MEE-S306','MEE',6,'Production Processes',4,'MEE-EID05'),('MEE-S307','MEE',6,'Design Of Machine Elements',4,'MEE-EID04'),('MEE-S308','MEE',6,'Lab-2, I C Engines, Heat Transfer ',4,'MEE-EID02'),('MEE-S401','MEE',7,'Computer Aided Manufacturing',4,'MEE-EID03'),('MEE-S402','MEE',7,'Refrigeration & Air-Conditioning',4,'MEE-EID04'),('MEE-S403','MEE',7,'Industrial Management & Production System',4,'MEE-EID07'),('MEE-S404','MEE',8,'Measurements and Controls',5,'MEE-EID01'),('MEE-S405','MEE',8,'Thermal Turbomachinery & Compressible Flows',4,'MEE-EID04'),('MEE-S406','MEE',8,'Fluid Machinery Lab',5,'MEE-EID03'),('MTH-S101','MEE',1,'Mathematics -I',4,'MTH-EID04'),('MTH-S102','MEE',2,'Mathematics-II',5,'MTH-EID02'),('MTH-S201','MEE',3,'Mathematics III',4,'MTH-EID05'),('PHY-S101','MEE',1,'Physics -I',5,'PHY-EID03'),('PHY-S102','MEE',2,'Physics-II',5,'PHY-EID03'),('PRT-S401','MEE',7,'B.Tech Project-I',4,'MEE-EID02'),('PRT-S402','MEE',8,'Computer Aided Design Lab',4,'MEE-EID02'),('SSM-S302','MEE',6,'Seminar',2,'MEE-EID01'),('SST-S301','MEE',7,'Summer Trainning',2,'MEE-EID01'),('TCA-S101','MEE',2,'Engineering Drawing',5,'MEE-EID03'),('TCA-S102','MEE',1,'Workshop Concept ',5,'MEE-EID04');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-09 15:10:10
