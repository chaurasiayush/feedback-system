-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: uiet
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `faculty` (
  `F_id` varchar(10) NOT NULL,
  `dep_id` varchar(10) DEFAULT NULL,
  `F_NAME` varchar(30) NOT NULL,
  `gender` varchar(1) NOT NULL,
  PRIMARY KEY (`F_id`),
  KEY `Faculty` (`dep_id`),
  CONSTRAINT `Faculty` FOREIGN KEY (`dep_id`) REFERENCES `department` (`dep_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES ('CHE-EID01','CHE','Dr. Vinay Kr. Sachan','M'),('CHE-EID02','CHE','DR. Brishti Mitra','F'),('CHE-EID03','CHE','Dr. Arun Kumar Gupta','M'),('CHE-EID04','CHE','Dr. Abhishek Chandra','M'),('CHE-EID05','CHE','Er. Umesh Chandra Sharma','M'),('CHE-EID06','CHE','Dr. Praveen Bhai Patel','M'),('CHE-EID07','CHE','Er. Arvid Sengar','M'),('CHE-EID08','CHE','Er. Vaibhav Saxena','M'),('CHM-EID01','CHM','Dr. Arpita Yadav','F'),('CHM-EID02','CHM','Dr. Rashmi Dubey','F'),('CHM-EID03','CHM','Dr. B.P. Singh','M'),('CHM-EID04','CHM','Dr. Ratna Shukla','F'),('CSE-EID01','CSE','Dr. Ravindra Nath','M'),('CSE-EID02','CSE','Dr. Renu Jain','F'),('CSE-EID03','CSE','Mr. Deepak Kumar Verma','M'),('CSE-EID04','CSE','Mr. Shesh Mani Tiwari','M'),('CSE-EID05','CSE','Mr. Mohd. Shah Alam','M'),('CSE-EID06','CSE','Dr. Sandesh Gupta','M'),('CSE-EID07','CSE','Mr. Alok Kumar','M'),('CSE-EID08','CSE','Mrs. Suruchi Kanaujiya','F'),('ECE-EID01','ECE','Er. Neeraj Kumar','M'),('ECE-EID02','ECE','Er. Vishal Awasthi','M'),('ECE-EID03','ECE','Er. Parul Awasthi','F'),('ECE-EID04','ECE','Er. Ajay Tiwari','M'),('ECE-EID05','ECE','Er. Somesh Malhotra','M'),('ECE-EID06','ECE','Er. Preeti Singh','F'),('ECE-EID07','ECE','Er. Atul Agnihotri','M'),('ECE-EID08','ECE','Dr. Richa Verma','F'),('ECE-EID09','ECE','Er. Ajeet Srivastava','M'),('ECE-EID10','ECE','Er. Anand Kumar Gupta','M'),('ECE-EID11','ECE','Er. Amit Kumar Katiyar','M'),('ECE-EID12','ECE','Er. Avinash Chaudhary','M'),('ECE-EID13','ECE','Er. Ompal','M'),('ECE-EID14','ECE','Er. Archana Verma','F'),('HSS-EID01','HSS','Dr. Richa Verma','F'),('HSS-EID02','HSS','Dr. Niyati Padhi','F'),('HSS-EID03','HSS','Dr. Vinita Kulshreshtha','F'),('HSS-EID04','HSS','Wg. Cdr. A. Basu','M'),('IT-EID01','IT','Dr. Rashi Agarwal','F'),('IT-EID02','IT','Er. Ramnayan Mishra','M'),('IT-EID03','IT','Er. Sanjeet Kumar','M'),('IT-EID04','IT','Er. Hemant Kumar','M'),('IT-EID05','IT','Er. Sunil Kumar','M'),('IT-EID06','IT','Er. Shubhendra Singh','M'),('IT-EID07','IT','Er. Prateek Srivastva','M'),('MEE-EID01','MEE','Er. Ramendra Singh Niranjan','M'),('MEE-EID02','MEE','Er. Pramod Kr. Singh','M'),('MEE-EID03','MEE','Mr. Ajeet Pratap Singh','M'),('MEE-EID04','MEE','Er. Arpit Srivastava','M'),('MEE-EID05','MEE','Er. Yastuti Rao Gautam','M'),('MEE-EID06','MEE','Er. Mukesh Kr Gupta','M'),('MEE-EID07','MEE','Er. Vikash Katiyar','M'),('MSME-EID01','MSME','Dr. Anju Dixit','M'),('MSME-EID02','MSME','Er. Vijay Kumar Kashyap','M'),('MSME-EID03','MSME','Er. Bhoomika Yadav','F'),('MSME-EID04','MSME','Er. Shivendra Kr. Trivedi','M'),('MSME-EID05','MSME','Er. Ankur Katiyar ','M'),('MSME-EID06','MSME','Er. Mangesh Kr. Vidyarthi','M'),('MTH-EID01','MTH','Dr. Varsha Gupta','F'),('MTH-EID02','MTH','Dr. V.N. Pal','M'),('MTH-EID03','MTH','Dr. Manoj Kumar Singh','M'),('MTH-EID04','MTH','Dr. Dharmendra Kumar Singh','M'),('MTH-EID05','MTH','Dr. Poonam Dixit','F'),('PHY-EID01','PHY','Dr. Saswati Sarkar','M'),('PHY-EID02','PHY','Dr. Ram Janma','M'),('PHY-EID03','PHY','Mr. Prabal Pratap Singh','M'),('PHY-EID04','PHY','Dr. Shikha Shukla','F'),('PHY-EID05','PHY','Dr. Anju Dixit','M');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-09 15:10:10
