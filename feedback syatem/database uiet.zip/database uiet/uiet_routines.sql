-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: uiet
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `facdep`
--

DROP TABLE IF EXISTS `facdep`;
/*!50001 DROP VIEW IF EXISTS `facdep`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `facdep` AS SELECT 
 1 AS `f_id`,
 1 AS `f_name`,
 1 AS `gender`,
 1 AS `dep_id`,
 1 AS `dep_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `busyfac`
--

DROP TABLE IF EXISTS `busyfac`;
/*!50001 DROP VIEW IF EXISTS `busyfac`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `busyfac` AS SELECT 
 1 AS `f_id`,
 1 AS `f_name`,
 1 AS `dep_id`,
 1 AS `sub_code`,
 1 AS `sub_name`,
 1 AS `teaching_dep`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_department`
--

DROP TABLE IF EXISTS `view_department`;
/*!50001 DROP VIEW IF EXISTS `view_department`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `view_department` AS SELECT 
 1 AS `dep_id`,
 1 AS `dep_name`,
 1 AS `dep_building`,
 1 AS `f_name`,
 1 AS `f_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `fb_view`
--

DROP TABLE IF EXISTS `fb_view`;
/*!50001 DROP VIEW IF EXISTS `fb_view`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `fb_view` AS SELECT 
 1 AS `f_id`,
 1 AS `f_name`,
 1 AS `gender`,
 1 AS `dep_id`,
 1 AS `branch`,
 1 AS `sub_code`,
 1 AS `sub_name`,
 1 AS `semester`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_feedback2`
--

DROP TABLE IF EXISTS `view_feedback2`;
/*!50001 DROP VIEW IF EXISTS `view_feedback2`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `view_feedback2` AS SELECT 
 1 AS `fid`,
 1 AS `teaching_dep_id`,
 1 AS `semester`,
 1 AS `sub_code`,
 1 AS `sub_name`,
 1 AS `teaching`,
 1 AS `marking`,
 1 AS `assignment`,
 1 AS `punctuality`,
 1 AS `NoOfRating`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `facdep`
--

/*!50001 DROP VIEW IF EXISTS `facdep`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `facdep` AS select `faculty`.`F_id` AS `f_id`,`faculty`.`F_NAME` AS `f_name`,`faculty`.`gender` AS `gender`,`faculty`.`dep_id` AS `dep_id`,`department`.`dep_name` AS `dep_name` from (`faculty` join `department` on((`faculty`.`dep_id` = `department`.`dep_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `busyfac`
--

/*!50001 DROP VIEW IF EXISTS `busyfac`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `busyfac` AS select `faculty`.`F_id` AS `f_id`,`faculty`.`F_NAME` AS `f_name`,`faculty`.`dep_id` AS `dep_id`,`subjects`.`sub_code` AS `sub_code`,`subjects`.`sub_name` AS `sub_name`,`subjects`.`dep_id` AS `teaching_dep` from (`subjects` left join `faculty` on((`subjects`.`F_id` = `faculty`.`F_id`))) order by `faculty`.`F_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_department`
--

/*!50001 DROP VIEW IF EXISTS `view_department`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_department` AS select `d`.`dep_id` AS `dep_id`,`d`.`dep_name` AS `dep_name`,`d`.`dep_building` AS `dep_building`,`f`.`F_NAME` AS `f_name`,`f`.`F_id` AS `f_id` from (`department` `d` left join `faculty` `f` on((`d`.`dep_hod` = `f`.`F_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `fb_view`
--

/*!50001 DROP VIEW IF EXISTS `fb_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `fb_view` AS select `f`.`F_id` AS `f_id`,`f`.`F_NAME` AS `f_name`,`f`.`gender` AS `gender`,`f`.`dep_id` AS `dep_id`,`s`.`dep_id` AS `branch`,`s`.`sub_code` AS `sub_code`,`s`.`sub_name` AS `sub_name`,`s`.`semester` AS `semester` from (`faculty` `f` join `subjects` `s` on((`f`.`F_id` = `s`.`F_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_feedback2`
--

/*!50001 DROP VIEW IF EXISTS `view_feedback2`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_feedback2` AS select `s`.`F_id` AS `fid`,`s`.`dep_id` AS `teaching_dep_id`,`s`.`semester` AS `semester`,`s`.`sub_code` AS `sub_code`,`s`.`sub_name` AS `sub_name`,avg(`f`.`r_teaching`) AS `teaching`,avg(`f`.`r_marking`) AS `marking`,avg(`f`.`r_asgn`) AS `assignment`,avg(`f`.`r_punctual`) AS `punctuality`,count(`f`.`r_teaching`) AS `NoOfRating` from (`subjects` `s` left join `feedbacks` `f` on(((`s`.`F_id` = `f`.`F_id`) and (`s`.`sub_code` = `f`.`sub_code`)))) group by `s`.`F_id`,`s`.`sub_code`,`s`.`dep_id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-09 15:10:11
